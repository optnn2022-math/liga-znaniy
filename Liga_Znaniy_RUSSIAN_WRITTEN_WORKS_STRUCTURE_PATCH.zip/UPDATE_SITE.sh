#!/usr/bin/env bash
set -e
git add russian/index.html russian/written-works.html
git commit -m "Add Russian written works hierarchy" || true
git push origin main
echo "Готово: изменения отправлены в GitHub. GitHub Pages обновится автоматически."
