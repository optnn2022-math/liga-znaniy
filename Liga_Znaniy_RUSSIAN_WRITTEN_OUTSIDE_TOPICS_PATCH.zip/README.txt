Patch: Russian written works OUTSIDE topic area.
1. unzip -o Liga_Znaniy_RUSSIAN_WRITTEN_OUTSIDE_TOPICS_PATCH.zip
2. bash APPLY_RUSSIAN_WRITTEN_OUTSIDE.sh
3. bash UPDATE_SITE.sh
