PATCH: Russian lesson 01 — approved site background + navigation cleanup

Changes ONLY russian/lesson-01.html:
1. Connects the same shared CSS files used by russian/index.html.
2. Removes the lesson's custom dark gradient so the main site's football-field background is used.
3. Hides the lesson-only decorative background letters.
4. Keeps only the ← Темы direct-navigation button.
5. Removes the duplicate Предметы button.
6. Does not change lesson tasks, stages, scoring, hero, or Russian main page.

Apply from repository root:
unzip -o Liga_Znaniy_RUSSIAN_LESSON01_BG_NAV_PATCH.zip
bash APPLY_RUSSIAN_LESSON01_BG_NAV.sh
bash UPDATE_SITE.sh
