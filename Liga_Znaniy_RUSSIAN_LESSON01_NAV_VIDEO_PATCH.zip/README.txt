Русский язык · урок 1 — NAV + VIDEO PATCH

Исправляет только:
- одну штатную кнопку «← Темы» в верхней панели;
- удаляет дублирующую плавающую кнопку;
- RUTUBE загружается при открытии этапа 2 «Разминка», когда блок уже видим;
- кнопка «← Темы» возвращает к russian/index.html.

Установка:
unzip -o Liga_Znaniy_RUSSIAN_LESSON01_NAV_VIDEO_PATCH.zip
bash APPLY_RUSSIAN_LESSON01_NAV_VIDEO_PATCH.sh
git add russian/lesson-01.html && git commit -m "Fix Russian lesson 01 navigation and video" && git push origin main
